module.exports = {
    plugin: {
        translation: require('./translation.plugin.js')
    }
};
