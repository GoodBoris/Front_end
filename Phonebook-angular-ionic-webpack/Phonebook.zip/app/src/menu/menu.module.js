export default angular.module('prototype.menu', [])
    //.config(modConfig)
    .name;
